plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tvboxgaming.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tvboxgaming.launcher"
        minSdk = 23
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}
