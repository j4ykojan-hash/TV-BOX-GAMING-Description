package com.tvboxgaming.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 12, 27)
    private val panel = Color.rgb(17, 29, 55)
    private val blue = Color.rgb(40, 105, 220)
    private lateinit var root: LinearLayout

    data class Game(val title: String, val category: String, val packageName: String?, val detail: String)

    private val games = listOf(
        Game("GTA SAN ANDREAS", "ROCKSTAR", "com.rockstargames.gtasa", "Clásico · Android"),
        Game("MINECRAFT", "AVENTURA", "com.mojang.minecraftpe", "Construcción y aventura"),
        Game("NINTENDO", "CLÁSICOS", null, "Abre aquí tu emulador instalado"),
        Game("ARCADE", "RETRO", null, "Abre aquí tu emulador arcade"),
        Game("PLAYSTATION", "CLÁSICOS", null, "Abre aquí tu emulador instalado")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildHome()
    }

    private fun buildHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(34, 24, 34, 28)
            setBackgroundColor(bg)
        }
        scroll.addView(root)
        setContentView(scroll)

        val top = TextView(this).apply {
            text = "TV BOX GAMING"
            textSize = 29f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        root.addView(top)

        val subtitle = TextView(this).apply {
            text = "PLAYSTATION EDITION   •   ANDROID"
            textSize = 12f
            setTextColor(Color.rgb(139, 177, 255))
            setPadding(0, 5, 0, 22)
        }
        root.addView(subtitle)

        val section = TextView(this).apply {
            text = "MIS JUEGOS"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 12)
        }
        root.addView(section)

        games.forEachIndexed { index, game ->
            val button = Button(this).apply {
                text = "${game.title}\n${game.detail}"
                textSize = 15f
                isAllCaps = false
                gravity = Gravity.CENTER_VERTICAL
                setTextColor(Color.WHITE)
                setBackgroundColor(panel)
                setPadding(22, 14, 22, 14)
                minHeight = 76
                setOnClickListener { openGame(game) }
                setOnFocusChangeListener { view, hasFocus ->
                    view.setBackgroundColor(if (hasFocus) blue else panel)
                    view.scaleX = if (hasFocus) 1.025f else 1f
                    view.scaleY = if (hasFocus) 1.025f else 1f
                }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = 10
            root.addView(button, lp)
            if (index == 0) button.requestFocus()
        }

        val settings = Button(this).apply {
            text = "AJUSTES  ·  INFORMACIÓN"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(35, 48, 75))
            setOnClickListener {
                Toast.makeText(this@MainActivity,
                    "TV BOX GAMING 1.0 · Android TV / control remoto", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(settings)
    }

    private fun openGame(game: Game) {
        val pkg = game.packageName
        if (pkg == null) {
            Toast.makeText(this, "Instala un emulador compatible y luego podrás abrirlo desde aquí.", Toast.LENGTH_LONG).show()
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) {
            startActivity(launch)
        } else {
            Toast.makeText(this, "${game.title}: no está instalado o esta versión usa otro identificador.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_BACK -> {
                buildHome()
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }
}
